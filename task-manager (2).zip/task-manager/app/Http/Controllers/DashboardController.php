<?php

namespace App\Http\Controllers;
use App\Models\Task; 
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        
        $query = Task::where('user_id', auth()->id());

        // Search by title or description
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Paginate tasks
        $tasks = $query->orderBy('due_date', 'asc')->paginate(10);

        // Counts for stats / pie chart
        $pendingCount = Task::where('user_id', auth()->id())->where('status', 'pending')->count();
        $inProgressCount = Task::where('user_id', auth()->id())->where('status', 'in_progress')->count();
        $completedCount = Task::where('user_id', auth()->id())->where('status', 'completed')->count();

        return view('dashboard', compact(
            'tasks', 
            'pendingCount', 
            'inProgressCount', 
            'completedCount'
        ));
    }


}
