<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    
    public function index(Request $request) // <-- inject the request
    {
        // Start query for the logged-in user's tasks
        $query = Task::where('user_id', auth()->id());

        // Search by title or description
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Order by due_date (soonest first) and paginate
        $tasks = $query->orderBy('due_date', 'asc')->paginate(10);


        return view('tasks.index', compact('tasks'));
    }


    public function create()
    {
        return view('tasks.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'due_date' => 'nullable|date',
        ]);

        auth()->user()->tasks()->create($request->all());

        return redirect()->route('tasks.index')->with('message','Task created successfully.');
    }

    public function edit(Task $task)
    {
        return view('tasks.edit', compact('task'));
    }

    public function update(Request $request, Task $task)
    {

        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'due_date' => 'nullable|date',
            'status' => 'nullable|in:pending,in_progress,completed'
        ]);

        $task->update($request->all());

        return redirect()->route('tasks.index')->with('message', 'Task updated successfully!');
    }

    // Delete
    public function destroy(Task $task)
    {
        $task->delete();

        if(request()->expectsJson()){
            return response()->json(['success' => true, 'message' => 'Task deleted successfully']);
        }

        return redirect()->back()->with('message', 'Task deleted successfully');
    }

    public function markCompleted(Task $task)
    {
        $task->status = 'completed';
        $task->save();

        if(request()->expectsJson()){
            return response()->json([
                'success' => true,
                'message' => 'Task marked as completed'
            ]);
        }

        return redirect()->back()->with('message', 'Task marked as completed');
    }

}
