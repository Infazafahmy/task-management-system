<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex h-screen bg-blue-100">

        <!-- Sidebar -->
        <aside class="bg-blue-900 text-white flex flex-col transition-all duration-300"
            x-data="{ open: true }"
            :class="open ? 'w-64' : 'w-20'">


            <!-- Sidebar Header -->
            <div class="flex flex-col items-center justify-center p-6 space-y-2 ":class="!open && 'justify-center'">

                <!-- Logo -->
                <div class="w-16 h-16">
                    <img src="<?php echo e(asset('assets/images/task.png')); ?>" alt="Logo" class="w-full h-full rounded-full object-cover">
                </div>
            
                <span class="text-2xl font-bold whitespace-nowrap text-center flex-1">
                    <span x-show="open">Task Manager</span>
                    <span x-show="!open">TM</span>
                </span>

                <!-- Collapse Button -->
                <button @click="open = !open" 
                        class="focus:outline-none bg-blue-700 hover:bg-blue-600 text-white rounded-full px-2 py-1 transition">
                    <span x-show="open" class="text-lg">⬅️</span>
                    <span x-show="!open" class="text-lg">➡️</span>
                </button>

                <!-- Horizontal Line -->
                <hr class="w-full border-t border-blue-100 ">


                


            <!-- Navigation Links -->
            <nav class="flex flex-col px-1 py-4 space-y-2 text-left space-y-2 w-full">

                <!-- Home -->
                <a href="<?php echo e(url('/')); ?>" 
                   class="flex items-center w-full px-4 py-2 rounded-lg transition
                   <?php echo e(request()->is('/') ? 'bg-blue-700 font-semibold' : 'hover:bg-blue-700'); ?>":class="!open && 'justify-center'">
                    <i class="fa-solid fa-house text-xl"></i>
                    <span x-show="open" class="mx-2 text-gray-400">|</span>
                    <span x-show="open" class="truncate">Home</span>
                </a>

                <!-- Dashboard -->
                <a href="<?php echo e(url('/dashboard')); ?>" 
                   class="flex items-center w-full px-4 py-2 rounded-lg transition
                   <?php echo e(request()->is('dashboard') ? 'bg-blue-700 font-semibold' : 'hover:bg-blue-700'); ?>":class="!open && 'justify-center'">
                    <i class="fa-solid fa-chart-line text-xl"></i>
                    <span x-show="open" class="mx-2 text-gray-400">|</span>
                    <span x-show="open" class="truncate" >Dashboard</span>
                </a>

                <!-- My Tasks -->
                <a href="<?php echo e(route('tasks.index')); ?>" 
                   class="flex items-center w-full px-4 py-2 rounded-lg transition
                   <?php echo e(request()->routeIs('tasks.index') ? 'bg-blue-700 font-semibold' : 'hover:bg-blue-700'); ?>":class="!open && 'justify-center'">
                    <i class="fa-solid fa-list-check text-xl"></i>
                    <span x-show="open" class="mx-2 text-gray-400">|</span>
                    <span x-show="open" class="truncate">My Tasks</span>
                </a>

                <!-- Logout -->
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" 
                            class="flex items-center w-full px-4 py-2 rounded-lg hover:bg-blue-700 transition":class="!open && 'justify-center'">
                        <i class="fa-solid fa-right-from-bracket text-xl"></i>
                        <span x-show="open" class="mx-2 text-gray-400">|</span>
                        <span x-show="open" class="truncate">Logout</span>
                    </button>
                </form>

            </nav>
               
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6 overflow-auto">

            <!-- Header -->
            <div class="bg-blue-800 text-white shadow rounded-lg p-4 mb-6 flex justify-between items-center">
                <h2 class="text-xl font-semibold">Dashboard</h2>

                <!-- Breeze Dropdown -->
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" 
                        class="flex items-center space-x-2 focus:outline-none 
                                border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-800 hover:bg-gray-100 transition">
                        <span class="font-medium"><?php echo e(Auth::user()->name); ?></span>
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M19 9l-7 7-7-7"/>
                        </svg>
                    </button>


                    <!-- Dropdown Menu -->
                    <div x-show="open" 
                         @click.away="open = false"
                         class="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                        <a href="<?php echo e(route('profile.edit')); ?>" 
                           class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                            Profile
                        </a>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" 
                                    class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                Logout
                            </button>
                        </form>
                    </div>
                </div>
            </div>
   
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                <div class="bg-blue-500 hover:bg-blue-600 text-white p-6 rounded-xl shadow-lg transition">
                    <h3 class="text-lg font-semibold mb-2">Pending</h3>
                    <p class="text-3xl font-bold"><?php echo e($pendingCount); ?></p>
                </div>
                <div class="bg-yellow-500 hover:bg-yellow-600 text-white p-6 rounded-xl shadow-lg transition">
                    <h3 class="text-lg font-semibold mb-2">In Progress</h3>
                    <p class="text-3xl font-bold"><?php echo e($inProgressCount); ?></p>
                </div>
                <div class="bg-green-500 hover:bg-green-600 text-white p-6 rounded-xl shadow-lg transition">
                    <h3 class="text-lg font-semibold mb-2">Completed</h3>
                    <p class="text-3xl font-bold"><?php echo e($completedCount); ?></p>
                </div>
            </div>    
    
            <div class="bg-white p-6 rounded-2xl shadow space-y-4">
                <!-- Search Form Container -->
                <div class="flex items-center justify-between mb-4 bg-white p-4 rounded-lg shadow">
                    <h2 class="text-2xl font-bold  px-4 py-2  text-blue-800 ">
                        My Tasks
                    </h2>
                    <!-- Search Form Right Aligned -->
                    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="flex gap-3 items-center">
                        <input type="text" 
                            name="search" 
                            value="<?php echo e(request('search')); ?>" 
                            placeholder="Search tasks..."
                            class="border rounded-lg p-2 w-56" />

                        <select name="status" class="border rounded-lg p-2 w-40 ">
                            <option value="" <?php echo e(request('status') == '' ? 'selected' : ''); ?>>All Tasks</option>
                            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="in_progress" <?php echo e(request('status') == 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                            <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Completed</option>
                        </select>

                        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 whitespace-nowrap">
                            Search
                        </button>
                    </form>
                </div>




                <!-- Tasks Table -->
                <div class="bg-white p-6 rounded-2xl shadow overflow-x-auto">
                    <table class="min-w-full border-collapse">
                        <thead>
                            <tr class="bg-gray-200 text-left">
                                <th class="p-3 border-b">Title</th>
                                <th class="p-3 border-b">Description</th>
                                <th class="p-3 border-b">Due Date</th>
                                <th class="p-3 border-b">Status</th>
                                <th class="p-3 border-b">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-3 border-b"><?php echo e($task->title); ?></td>
                                <td class="p-3 border-b"><?php echo e($task->description); ?></td>
                                <td class="p-3 border-b"><?php echo e($task->due_date); ?></td>
                                <td class="p-3 border-b">
                                    <span class="px-2 py-1 rounded-full text-sm
                                        <?php echo e($task->status == 'pending' ? 'bg-blue-100 text-blue-700' : ($task->status == 'in_progress' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700')); ?>">
                                        <?php echo e(ucfirst(str_replace('_',' ',$task->status))); ?>

                                    </span>
                                </td>
                                <td class="p-3 border-b flex gap-2">
                                    <a href="<?php echo e(route('tasks.edit',$task)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded">Edit</a>
                                    <!-- Delete -->
                                    <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" class="delete-task-form">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded">Delete</button>
                                    </form>

                                    <!-- Mark Completed -->
                                    <?php if($task->status !== 'completed'): ?>
                                    <form action="<?php echo e(route('tasks.complete', $task)); ?>" method="POST" class="complete-task-form">
                                    <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
                                    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-2 py-1 rounded">
                                        Mark Completed
                                    </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <?php echo e($tasks->links()); ?>

                    </div>
                </div>
            </div>

        </main>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    // Delete confirmation
    document.querySelectorAll('.delete-task-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // prevent default submit
            Swal.fire({
                title: 'Are you sure?',
                text: "This task will be permanently deleted!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e11d48', // Tailwind red-600
                cancelButtonColor: '#6b7280', // Tailwind gray-500
                confirmButtonText: 'Yes, delete it!',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // submit the form
                }
            });
        });
    });

    // Mark completed confirmation
    document.querySelectorAll('.complete-task-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Mark as Completed?',
                text: "This will update the task status to completed.",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#16a34a', // Tailwind green-600
                cancelButtonColor: '#6b7280', // Tailwind gray-500
                confirmButtonText: 'Yes, mark completed',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });

    // Optional: success alert for session message
    <?php if(session('message')): ?>
    Swal.fire({
        title: 'Success!',
        text: "<?php echo e(session('message')); ?>",
        icon: 'success',
        confirmButtonColor: '#3b82f6', // Tailwind blue-600
        confirmButtonText: 'OK'
    });
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp2\htdocs\task-manager\task-manager\resources\views/dashboard.blade.php ENDPATH**/ ?>