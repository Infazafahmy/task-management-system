
<!-- Header -->
    <header class="fixed top-0 left-0 right-0 z-50 bg-blue-900 text-white shadow">
        <div class="max-w-7xl mx-auto flex justify-between items-center p-4">
            <h1 class="text-2xl font-bold">Task Manager</h1>
                <nav class="space-x-4 flex items-center">
                    <a href="<?php echo e(url('/')); ?>" 
                    class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('/') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                        Home
                    </a>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" 
                            class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('dashboard') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                                Dashboard
                            </a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="px-3 py-2 rounded-lg hover:bg-blue-600">
                                    Logout
                                </button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" 
                            class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('login') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                                Login
                            </a>
                            <a href="<?php echo e(route('register')); ?>" 
                            class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('register') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                                Register
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </nav>
        </div>
    </header><?php /**PATH C:\xampp2\htdocs\task-manager\task-manager port 3307\resources\views/components/header.blade.php ENDPATH**/ ?>