<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Task Manager</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="antialiased bg-gray-100 text-gray-900">

    <!-- Header -->
    <header class="fixed top-0 left-0 right-0 z-50 bg-blue-900 text-white shadow">
        <div class="max-w-7xl mx-auto flex justify-between items-center p-4">
            <h1 class="text-2xl font-bold">Task Manager</h1>
                <nav class="space-x-4 flex items-center">
                    <a href="<?php echo e(url('/')); ?>" 
                    class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('/') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                        Home
                    </a>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" 
                            class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('dashboard') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                                Dashboard
                            </a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="px-3 py-2 rounded-lg hover:bg-blue-600">
                                    Logout
                                </button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" 
                            class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('login') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                                Login
                            </a>
                            <a href="<?php echo e(route('register')); ?>" 
                            class="px-3 py-2 rounded-lg transition-colors <?php echo e(request()->is('register') ? 'bg-blue-700' : 'hover:bg-blue-600'); ?>">
                                Register
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </nav>

        </div>
    </header>

    <!-- Hero Section -->
    <section class="relative bg-gradient-to-r from-blue-600 via-blue-500 to-blue-400 h-[500px] flex items-center justify-center">
        <div class="text-center text-white max-w-2xl">
            <h2 class="text-5xl font-bold mb-4">Organize Your Work, Achieve More</h2>
            <p class="text-lg mb-6">Stay productive with Task Manager. Create, track, and complete tasks with ease.</p>
            <div class="space-x-4">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('register')); ?>" class="px-5 py-3 bg-white text-blue-900 font-semibold rounded-xl hover:bg-gray-300">
                        Get Started
                    </a>
                    <a href="<?php echo e(route('login')); ?>" class="px-5 py-3 bg-white text-blue-900 font-semibold rounded-xl hover:bg-gray-300">
                        Login
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="px-5 py-3 bg-white text-blue-900 font-semibold rounded-xl hover:bg-gray-300">
                        Go to Dashboard
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="max-w-7xl mx-auto py-16 px-6 grid md:grid-cols-3 gap-8 text-center">
        <div class="bg-white p-6 rounded-2xl shadow-lg">
            <h3 class="text-xl font-bold mb-3">✅ Easy Task Management</h3>
            <p class="text-blue-900">Create, update, and track tasks with deadlines and status.</p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-lg">
            <h3 class="text-xl font-bold mb-3">📊 Dashboard Overview</h3>
            <p class="text-blue-900">View tasks grouped by Pending, In Progress, and Completed.</p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-lg">
            <h3 class="text-xl font-bold mb-3">🔒 Secure Authentication</h3>
            <p class="text-blue-900">Register and log in with Breeze authentication system.</p>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-blue-900 text-white text-center py-6 mt-12">
        <p>&copy; <?php echo e(date('Y')); ?> Task Manager. All rights reserved.</p>
    </footer>

</body>
</html>
<?php /**PATH C:\xampp2\htdocs\task-manager\task-manager port 3307\resources\views/welcome.blade.php ENDPATH**/ ?>